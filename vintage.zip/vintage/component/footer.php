<!-- footer -->
  <div class="container-fluid" id="footer">
    <div class="row">
      <div class="col-xs-3 text-white">
        <img src="asset/img/Brand1.png">
        <p style="padding-left: 1.3vw;margin-top: 15px; font-family: Tahoma; font-size: 15px">
        Vintage & Thrifting Surabaya menyediakan berbagai macam pilihan kaos yang anti-mainstream namun tetap upgrade sesuai perkembangan zaman.
        </p>
        <ul>
          <li>STORE: JL.BAWEAN NO 42</li>
          <li>💥OPEN: 14.00-20:00</li>
          <li>💥SELLING & CONSIGMENT</li>
          <li>🏦 Paypal ready</li>
          <li>🛩 World wide shiping</li>
        </ul>
      </div>
      
      <div class="col-xs-3 col-xs-offset-1 text-white">
        <h3 style="font-family:Cooper Std Black">Lokasi Kami</h3>
        <hr>
        <!-- <div id="map" style="width:20vw;height:30vh;background:yellow; border-radius:5px"></div>
        <script>
          function myMap() {
            var mapOptions = {
                center: new google.maps.LatLng(-7.276476, 112.795118),
                zoom: 16,
                mapTypeId: google.maps.MapTypeId.HYBRID
            }
            var map = new google.maps.Map(document.getElementById("map"), mapOptions);
          }
        </script> 
        <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDfbNrFraqA4e6NB-zwCqbzpwDrGIwbbEg&callback=myMap"></script> -->
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3957.6719043589715!2d112.74610011477495!3d-7.278122794746743!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd7fbc51edf1ca5%3A0xc53c17364c557e81!2sJl.%20Bawean%20No.42%2C%20RT.002%2FRW.04%2C%20Ngagel%2C%20Kec.%20Wonokromo%2C%20Kota%20SBY%2C%20Jawa%20Timur%2060246!5e0!3m2!1sen!2sid!4v1631034499496!5m2!1sen!2sid" width="300" height="200" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
      </div>
      
      <div class="col-xs-3 col-xs-offset-1 text-white">
      <h3 style="font-family:Cooper Std Black">Sosial Media </h3>
      <hr>
      <br>
        <a href="#" class="list-group-item"><img style="width: 40px; height: 40px; margin-right: 1vw;" src="asset/img/youtube.png"> Youtube</a>
        <a href="#" class="list-group-item"><img style="width: 40px; height: 40px; margin-right: 1vw;" src="asset/img/facebook.png"> Facebook</a>
        <a href="https://www.instagram.com/vintagebysubthrift/" class="list-group-item"><img style="width: 40px; height: 40px; margin-right: 1vw;" src="asset/img/instagram.png"> Instagram</a>
      </div>

    </div>
    <div class="row" id="cpy">
      <div class="col-xs-12">
        <p style="color : white; text-align: center;"><?php echo "Copyright © " . (int)date('Y') . " Vintage & Thrifting Surabaya"; ?></p>
      </div>
    </div>
  </div>
<!-- end of footer -->