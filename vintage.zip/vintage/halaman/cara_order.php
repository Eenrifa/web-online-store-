<div class="col-xs-6 col-xs-offset-3">
    <div class="panel panel-default">
  <!-- Default panel contents -->
  <div class="panel-heading">Cara Order</div>
  <div class="panel-body">
  <img src="asset/img/Brand.png" class="img-thumbnail center-block" width="200px"><br/>
  <h4 class="list-group-item-heading">Proses Pembelian</h4>
  <p>
Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
</p>
<hr/>
    <h4 class="list-group-item-heading">Proses Pembayaran</h4>
  <p>
Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
</p>
  </div>
    <ul class="list-group">
    <li class="list-group-item"><strong>Nomor Rekening</strong></li>
    <li class="list-group-item">Lorem ipsum dolor sit amet, </li>
    <li class="list-group-item">consectetur adipiscing elit,</li>
    <li class="list-group-item">sed do eiusmod <a href="#">tempor</a> incididunt</li>
    </ul>
</div>
</div>

