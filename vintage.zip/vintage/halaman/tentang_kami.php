<div class="col-xs-6 col-xs-offset-3">
    <div class="panel panel-default">
  <!-- Default panel contents -->
  <div class="panel-heading">Vintage & Thrifting Surabaya</div>
  <div class="panel-body">
  <img src="asset/img/Brand.png" class="img-thumbnail center-block" width="200px"><br/>
    <p>Vintage & Thrifting Surabaya menyediakan berbagai macam pilihan kaos yang anti-mainstream namun tetap upgrade sesuai perkembangan zaman.
    </p>
  </div>
    <ul class="list-group">
    <li class="list-group-item">STORE: JL.BAWEAN NO 42</li>
    <li class="list-group-item">💥OPEN: 14.00-20:00</li>
    <li class="list-group-item">💥SELLING & CONSIGMENT</li>
    <li class="list-group-item">🏦 Paypal ready</li>
    <li class="list-group-item">🛩 World wide shiping</li>
    </ul>
    <div class="panel-footer">
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3957.6719043589715!2d112.74610011477495!3d-7.278122794746743!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd7fbc51edf1ca5%3A0xc53c17364c557e81!2sJl.%20Bawean%20No.42%2C%20RT.002%2FRW.04%2C%20Ngagel%2C%20Kec.%20Wonokromo%2C%20Kota%20SBY%2C%20Jawa%20Timur%2060246!5e0!3m2!1sen!2sid!4v1631107827257!5m2!1sen!2sid" width="550px" style="border:0;" allowfullscreen="" loading="lazy"></iframe></div>
</div>
</div>