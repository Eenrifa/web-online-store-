<div class="col-xs-6 col-xs-offset-3">
<div class="list-group">
  <a href="#" class="list-group-item disabled">
    Hubungi Melalui:
  </a>
<a href="#" class="list-group-item"><h4>WhatsApp, Telpon, SMS</h4></a>
<a href="#" class="list-group-item"><img style="width: 40px; height: 40px; margin-right: 1vw;" src="asset/img/whatsapp.png"> 0899-7766-8899</a>

<a href="#" class="list-group-item"><h4>Sosial Media</h4></a>
<a href="#" class="list-group-item"><img style="width: 40px; height: 40px; margin-right: 1vw;" src="asset/img/youtube.png"> Youtube</a>
<a href="#" class="list-group-item"><img style="width: 40px; height: 40px; margin-right: 1vw;" src="asset/img/facebook.png"> Facebook</a>
<a href="https://www.instagram.com/vintagebysubthrift/" class="list-group-item"><img style="width: 40px; height: 40px; margin-right: 1vw;" src="asset/img/instagram.png"> Instagram</a>
</div>
</div>