<div class="col-xs-6 col-xs-offset-3">
    <div class="panel">
    <h3>Konfirmasi </h3>
    <hr>
    <br>
    <form action="./proses/komentar.php" method="post" role="form">
        <div class="form-group">
        <label for="nama">Nama : </label>
        <input type="text" class="form-control" name="nama" placeholder="Nama">
        </div>
        <div class="form-group">
        <label for="email">Email : </label>
        <input type="text" class="form-control" name="email" placeholder="Email">
        </div>
        <div class="form-group">
        <label for="pesan">Pesan : </label>
        <textarea class="form-control" name="pesan" placeholder="Masukkan pesan "></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Kirim</button>
    </form>
</div>
</div>