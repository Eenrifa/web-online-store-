<style>
.col-container {
    width: 19%;
    display: inline-flex;
}
}
.col {
  flex: 1;
  padding: 16px;
}
.limit{
  overflow: hidden;
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
}
</style>
    <!-- pria -->
    <?php 
    require("config/db.php");
    $limit = 5;
    $sql = mysqli_query($conn, "SELECT count(idProduk) FROM tabel_produk WHERE kategori='pria'");
    $row = mysqli_fetch_array($sql, MYSQLI_NUM);
    $rec_count = $row[0];
    if(isset($_GET['page'])){
        $page = $_GET['page'] + 1;
        $offset = $limit * $page;
    }else{
        $page = 0;
        $offset = 0;
    }
    $left_rec = $rec_count - ($page * $limit);
    $queryPria = "SELECT * FROM tabel_produk WHERE kategori='pria' LIMIT $offset,$limit";
    $query_pria = mysqli_query($conn, $queryPria);
        while($arrayPria = mysqli_fetch_array($query_pria)){
          echo '
            <div class="col-container">
                <div class="col">
                        <img src="admin/proses/'.$arrayPria['path'].'" alt="'.$arrayPria['nama'].'" class="thumbnail" width="200" height="200">
                        <p class="limit">'.$arrayPria['nama'].'</p>
                        <!-- <span></span> -->
                    <p><a href="#'.$arrayPria['idProduk'].'" class="btn btn-success" role="button">Detail</a> 
                    <a href="#" class="btn btn-warning disabled" role="button">Rp.'.$arrayPria['harga'].'</a>
                    </p>
                </div>
            </div>
            <div class="overlay" id="'.$arrayPria['idProduk'].'">
                <a href="#" class="close"><i class="glyphicon glyphicon-remove"></i></a>
                <img src="admin/proses/'.$arrayPria['path'].'">
                <div class="keterangan">
                    <div class="container">
                        <h4><strong>'.$arrayPria['nama'].'</strong></h4>
                        <p>'.$arrayPria['keterangan'].'</p>
                        <h5>Rp.'.$arrayPria['harga'].'</h5>
                        <h5 class="ukur">Ukuran : '.$arrayPria['ukuran'].'</h5>
                        <button type="button" class="btn btn-success">Stock : '.$arrayPria['stock'].'</button>
                        ';
                        if(isset($_SESSION['idUser'])){
                        if($arrayPria['stock'] > 0){
                        echo '
                        <a href="proses/beli.php?idProduk='.$arrayPria['idProduk'].'&idUser='.$iduser.'"><button type="button" class="btn btn-info">Masukkan Keranjang</button></a>
                        ';
                        }else{
                        echo '
                        <button type="button" class="btn btn-info disabled">Masukkan Keranjang</button>
                        <small class="text-right"><p class="text-right">* silahkan login agar bisa order</p></small>
                        ';
                        }
                        }else{
                        echo '
                        <button type="button" class="btn btn-info disabled">Masukkan Keranjang</button>
                        <small class="text-right"><p class="text-right">* silahkan login agar bisa order</p></small>
                        ';
                        }
                        echo '
                    </div>
                </div>
            </div>
          ';
        }
        ?>
      <!-- <div class="clear"></div> -->
    <div class="container-fluid" id="paging">
        <div class="paging">
            <?php 
            if($left_rec < $limit){
                $last = $page - 2;
                echo "<a href = \"?page=$last\"><button type='button' class='btn btn-primary left'>Previous</button></a>";
                }else if($page > 0){
                $last = $page - 2;
                echo "<a href = \"?page=$last\"><button type='button' class='btn btn-primary left'>Previous</button></a>";
                echo "<a href = \"?page=$page\"><button type='button' class='btn btn-primary right'>Next</button></a>";
                }else if( $page == 0 ) {
                echo "<a href = \"?page=$page\"><button type='button' class='btn btn-primary right'>Next</button></a>";
                }
            ?>
        </div>
    </div> <!-- end of pria -->