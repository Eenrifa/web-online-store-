<!DOCTYPE html>
<html>
<head>
  <title>Vintage & Thrifting Surabaya</title>
  <link rel="stylesheet" type="text/css" href="plugin/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="asset/css/main.css">
  <link rel="icon" type="image/gif/png" href="asset/img/Title.png">
</head>
<body>
<!-- navbar -->
<nav class="navbar navbar-fixed">
  
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="home.php">
        <img style="width:14vw; height:7vh; padding-top:0px;" alt="Brand" src="asset/img/Brand1.png">
      </a>
    </div>

    <ul class="nav navbar-nav navbar-right" >
      <li>
        <?php 
          $conn = mysqli_connect('localhost', 'root', '', 'vintage');
          if(isset($_SESSION['idUser'])){
            $iduser = $_SESSION['idUser'];
            $queryUser = mysqli_query($conn, "SELECT * FROM tabel_user WHERE idUser='$_SESSION[idUser]'");
            $arrayUser = mysqli_fetch_array($queryUser);
            echo '
                <a href="proses/logout.php"><button class="btn navbar-btn" id="btn-logout" style="color:#7986cb;margin-top:-0.8vh;
                background-color: white;"><b>Logout</b></button></a>
            ';
          }else{
            echo '
                <button class="btn navbar-btn" id="btn-login"><b>Login</b></button>
            ';
          }
       ?>
      </li>
      <li style="border-left: 1px solid white">
      <?php 
        $conn = mysqli_connect('localhost', 'root', '', 'vintage');
        if(isset($_SESSION['idUser'])){
          echo '
            <a class="not-active" href="keranjang.php" data-toggle="tooltip" data-placement="bottom" title="Keranjang"  ><i class="glyphicon glyphicon-shopping-cart" id="trolly"></i></a>
          ';
        }else{
          echo '
            <a class="not-active" href="#" data-toggle="tooltip" data-placement="bottom" title="Keranjang"  ><i class="glyphicon glyphicon-shopping-cart" id="trolly"></i></a>
          ';
        }
       ?>
      </li>
    </ul>
    
    <form action="pencarian.php" method="get" class="navbar-form navbar-right" style="margin-top: 4vh">
      <div class="input-group" style="width:45vw; margin-right: 8vw; margin-top: 1vh;">
        <input type="text" class="form-control" placeholder="Search Product" name="keyword">
        <div class="input-group-btn">
          <button class="btn btn-default" type="submit">
            <i class="glyphicon glyphicon-search" style="opacity: 0.7"></i>
          </button>
        </div>
      </div>
    </form>


  <!-- userLog -->
  <div class="container" id="log">
    <ul class="nav nav-tabs nav-justified">
      <li><a href="#freg" data-toggle="tab" style="font-style:bold;font-size: 1.2em; color:#1c6def">Daftar</a></li>
      <li class="active"><a href="#flogin" data-toggle="tab" style="font-style:bold;font-size: 1.2em; color:#1c6def">Login</a></li>
    </ul>
    <div class="tab-content">
        <form action="proses/login.php" method="post" role="form" id="flogin" style="padding-top: 10px" class="tab-pane fade in active">
        <div class="form-group">
          <label for="email">Email :</label>
          <input type="email" class="form-control" id="email" name="email">
        </div>
        <div class="form-group">
          <label for="pwd">Password :</label>
          <input type="password" class="form-control" id="pwd" name="password">
        </div>

        <button type="submit" class="btn btn-primary">Login</button>
      </form>

      <form action="proses/daftar.php" method="post" role="form" id="freg" style="padding-top: 10px" class="tab-pane fade">
        <div class="form-group">
          <label for="nama">Nama :</label>
          <input type="text" class="form-control" id="nama" name="nama" required>
        </div>
        <div class="form-group">
          <label for="noTelp">Nomor Telepon :</label>
          <input type="telp" class="form-control" id="noTelp" name="telpon" required>
        </div>
        <div class="form-group">
          <label for="email">Email :</label>
          <input type="email" class="form-control" id="email" name="email" required>
        </div>
        <div class="form-group">
          <label for="alamat">Alamat :</label>
          <input type="text" class="form-control" id="alamat" name="alamat" required>
        </div>
        <div class="form-group">
          <label for="pwd">Password :</label>
          <input type="password" class="form-control" id="pwd" name="password" required>
        </div>
        <div class="form-group">
          <label for="pwd2">Konfirmasi Password :</label>
          <input type="password" class="form-control" id="pwd2" name="repassword" required>
        </div>
        <button type="submit" class="btn btn-primary">Daftar</button>
      </form>
    </div>
  </div>
</nav>
<!-- end of navbar -->

<div class="container-fluid">
    <div class="row">
        <div class="col-xs-6 col-xs-offset-3" id="produk-laris">
            <!-- <h3 style="font-family: Blacksword; font-size:2.2em;"><strong>Welcome</strong></h3> -->
          <ul class="list-group list-group-horizontal">
            <li class="list-group-item">
                <!-- <div class="btn-group">
                    <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Kategori Produk <span class="caret"></span>
                    <span class="sr-only">Toggle Dropdown</span>
                    </button>
                    <ul class="dropdown-menu">
                    <li>  <a href="#">Pria</a></li>
                    <li>  <a href="#">Wanita</a></li>
                    <li>  <a href="#">Anak</a></li>
                    <li>  <a href="home.php#kaosband">Kaos Band</a></li>
                    <li>  <a href="#">Kaos Anime</a></li>
                    </ul>
                </div> -->
              <div class="btn-group">
                <a href="./home.php" class="btn btn-default">Home</a>
                <a href="./halaman.php?page=tentang_kami" class="btn btn-default">Tentang Kami</a>
                <a href="./halaman.php?page=cara_order" class="btn btn-default">Cara Order</a>
                <a href="./halaman.php?page=konfirmasi" class="btn btn-default">Konfirmasi</a>
                <a href="./halaman.php?page=hubungi_kami" class="btn btn-default">Hubungi Kami</a>
              </div>
            </li>
          </ul>
        </div>
    </div>
    <div class="panel panel-default">
        <div class="panel-body">
            <?php 
                include 'config/db.php';
                if (empty($_GET["page"])) {
                    include "halaman/display.php";
                }
                elseif ($_GET['page']=='kategori_produk') {
                    include "halaman/kategori_produk.php";
                } 
                elseif ($_GET['page']=='tentang_kami') {
                    include "halaman/tentang_kami.php";
                } 
                elseif ($_GET['page']=='cara_order') {
                    include "halaman/cara_order.php";
                }
                elseif ($_GET['page']=='konfirmasi') {
                    include "halaman/konfirmasi.php";
                }
                elseif ($_GET['page']=='hubungi_kami') {
                    include "halaman/hubungi_kami.php";
                }
            ?>
        </div>
    </div>
</div>
<script type="text/javascript" src="plugin/Javascript/jquery.min.js"></script>
<script type="text/javascript" src="plugin/bootstrap/js/bootstrap.js"></script>
<script type="text/javascript" src="asset/js/script.js"></script>
</body>
</html>