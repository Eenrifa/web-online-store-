<?php 
  $conn = mysqli_connect('localhost', 'root', '', 'vintage');

  $nama = $_POST['nama'];
  $email = $_POST['email'];
  $pesan = $_POST['pesan'];
  $query = mysqli_query($conn, " INSERT INTO tabel_komentar (nama, email, pesan) VALUES ('$nama', '$email', '$pesan')");
  
  if($query){
    echo '
      <script>
        alert("Konfirmasi sudah dikirim !");
        window.location = "../home.php"
      </script>
    ';
  }else{
    echo '
      <script>
        alert("Konfirmasi tidak terkirim, coba ulangi !");
        window.location = "../home.php"
      </script>
    ';
  }
 ?>