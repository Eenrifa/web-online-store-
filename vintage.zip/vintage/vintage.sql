-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 10, 2021 at 01:20 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.4.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vintage`
--

-- --------------------------------------------------------

--
-- Table structure for table `tabel_admin`
--

CREATE TABLE `tabel_admin` (
  `idAdmin` varchar(11) NOT NULL,
  `namaAdmin` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tabel_admin`
--

INSERT INTO `tabel_admin` (`idAdmin`, `namaAdmin`, `email`, `password`) VALUES
('1', 'admin', 'admin@gmail.com', '21232f297a57a5a743894a0e4a801fc3'),
('2', 'Armin', 'armin@gmail.com', 'cf3384d079ddcb4ca02fadab6be9802d');

-- --------------------------------------------------------

--
-- Table structure for table `tabel_kategori`
--

CREATE TABLE `tabel_kategori` (
  `idKategori` int(11) NOT NULL,
  `namaKategori` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tabel_kategori`
--

INSERT INTO `tabel_kategori` (`idKategori`, `namaKategori`) VALUES
(1, 'Pria'),
(2, 'Wanita'),
(3, 'Anak-anak'),
(6, 'Kaos Band'),
(7, 'Kaos Anime');

-- --------------------------------------------------------

--
-- Table structure for table `tabel_keranjang`
--

CREATE TABLE `tabel_keranjang` (
  `idKeranjang` varchar(11) NOT NULL,
  `idUser` int(11) NOT NULL,
  `idProduk` varchar(11) NOT NULL,
  `namaProduk` varchar(100) NOT NULL,
  `harga` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tabel_komentar`
--

CREATE TABLE `tabel_komentar` (
  `idKomen` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `pesan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tabel_komentar`
--

INSERT INTO `tabel_komentar` (`idKomen`, `nama`, `email`, `pesan`) VALUES
(1, 'Samsul', 'syamsulganteng@gmail.com', 'Saya sudah melakukan transfer, mohon di cek'),
(2, 'Nurjanah', 'nurjanah@gmail.com', 'Saya sudah melakukan pembayaran');

-- --------------------------------------------------------

--
-- Table structure for table `tabel_produk`
--

CREATE TABLE `tabel_produk` (
  `idProduk` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `gambar` text NOT NULL,
  `ukuran` varchar(100) NOT NULL,
  `keterangan` text NOT NULL,
  `kategori` varchar(50) NOT NULL,
  `harga` int(11) NOT NULL,
  `stock` int(11) NOT NULL,
  `path` varchar(50) NOT NULL,
  `size` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tabel_produk`
--

INSERT INTO `tabel_produk` (`idProduk`, `nama`, `gambar`, `ukuran`, `keterangan`, `kategori`, `harga`, `stock`, `path`, `size`) VALUES
(17, 'Batik Wanita', '1eb1b942e285179d983d61ab70c9ef85', 'S', 'Batik Wanita', 'wanita', 200000, 2, 'image/1eb1b942e285179d983d61ab70c9ef85.png', 25352),
(18, 'Batik Anak-anak', '672c674ef1b7e42c603e55276530f2e6', 'S', 'Batik Anak-anak', 'anak', 150000, 5, 'image/672c674ef1b7e42c603e55276530f2e6.png', 48736),
(21, 'Kaos Anime', '3397293c29a05ca24442d54356fbd6e4', 'L', 'Kaos Anime Terbaru 2021, Bahan Cotton Combat', 'kaosanime', 120000, 10, 'image/3397293c29a05ca24442d54356fbd6e4.png', 117828),
(22, 'Kaos Band Van Hallen Cover Album Balance', '682040774bf60451510975ba984ea992', 'M', 'Kaos Band Van Hallen bergambar Cover dari Album Balance, berbahan Cotton Combad Dingin. Nyaman dipakai disaat siang hari.', 'kaosband', 115000, 6, 'image/682040774bf60451510975ba984ea992.png', 71464),
(23, 'Kaos Megadeth Putih Album Cover Youthanasia', 'c75668fb1335d50ed01ec846076fe8a0', 'M', 'Megadeth Youthanasia Putih\r\nSize: L\r\nPxL: 81x54', 'pria', 105000, 1, 'image/c75668fb1335d50ed01ec846076fe8a0.png', 67806),
(24, 'Kaos Band The Smashing Pumpkins', '1e236a3c27ec003243a64b526ea9a674', 'S', 'The Smashing Pumpkins\r\nSize: L\r\nPxL: 81x56\r\nPrice: SOLD', 'pria', 145000, 0, 'image/1e236a3c27ec003243a64b526ea9a674.png', 91833),
(25, 'Kaos Nirvana Hitam', '21c37acd10e343489d3c108a40eaec04', 'M', 'Nirvana\r\nSize: M\r\nPxL: 68x52\r\nPrice: SOLD', 'pria', 180000, 4, 'image/21c37acd10e343489d3c108a40eaec04.png', 95919),
(26, 'Deep Purple Machine Head', '304a96ab340ff3587e37d7b1cb77e289', 'L', 'Deep Purple Machine Head 1993??\r\nP 70 x L 59\r\nSize on tag: Large\r\nfront hit ??\r\nback hit ??', 'pria', 156000, 8, 'image/304a96ab340ff3587e37d7b1cb77e289.png', 203755),
(27, 'Kaos R.Kelly ', '1fc5278e28d4178266a75207f5644e3e', 'XL', 'Kaos R.Kelly 12 Play albums\r\nSize L ( 74 x 54 )\r\nFront hit ??\r\nBack hit ??', 'pria', 215000, 37, 'image/1fc5278e28d4178266a75207f5644e3e.png', 101360);

-- --------------------------------------------------------

--
-- Table structure for table `tabel_transaksi`
--

CREATE TABLE `tabel_transaksi` (
  `idTransaksi` int(11) NOT NULL,
  `idUser` varchar(11) NOT NULL,
  `daftarBarang` text NOT NULL,
  `tanggal` date NOT NULL,
  `total` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tabel_transaksi`
--

INSERT INTO `tabel_transaksi` (`idTransaksi`, `idUser`, `daftarBarang`, `tanggal`, `total`) VALUES
(3, '1', 'Kaos Nirvana Hitam, Kategori : pria, Jumlah : 2<br>', '2021-09-08', 2623000),
(4, '1', 'Kaos Band The Smashing Pumpkins, Kategori : pria, Jumlah : 1<br>', '2021-05-12', 123000),
(5, '1', 'Deep Purple Machine Head, Kategori : pria, Jumlah : 1<br>', '2021-03-03', 100000),
(6, '4', 'Kaos Megadeth Putih Album Cover Youthanasia, Kategori : pria, Jumlah : 1<br>', '2021-09-07', 100000),
(7, '4', 'Kaos Megadeth Putih Album Cover Youthanasia, Kategori : pria, Jumlah : 1<br>', '2021-09-08', 105000),
(8, '4', 'Deep Purple Machine Head, Kategori : pria, Jumlah : 1<br>', '2021-09-08', 156000),
(9, '4', 'Kaos Band The Smashing Pumpkins, Kategori : pria, Jumlah : 1<br>', '2021-09-08', 145000),
(10, '4', 'Kaos Nirvana Hitam, Kategori : pria, Jumlah : 1<br>', '2021-09-08', 180000);

-- --------------------------------------------------------

--
-- Table structure for table `tabel_trolly`
--

CREATE TABLE `tabel_trolly` (
  `idTrolly` int(11) NOT NULL,
  `idUser` int(11) NOT NULL,
  `idProduk` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tabel_user`
--

CREATE TABLE `tabel_user` (
  `idUser` int(11) NOT NULL,
  `namaUser` varchar(50) NOT NULL,
  `email` varchar(70) NOT NULL,
  `password` varchar(40) NOT NULL,
  `alamat` text NOT NULL,
  `telpon` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tabel_user`
--

INSERT INTO `tabel_user` (`idUser`, `namaUser`, `email`, `password`, `alamat`, `telpon`) VALUES
(1, 'user1', 'user1@gmail.com', '24c9e15e52afc47c225b757e7bee1f9d', 'surabaya', '234234'),
(4, 'Mindroid', 'cozyhijab@gmail.com', '15c5eed67b2cc97e1dd5c8601764e533', 'Singkawang', '089673717878');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tabel_admin`
--
ALTER TABLE `tabel_admin`
  ADD PRIMARY KEY (`idAdmin`);

--
-- Indexes for table `tabel_kategori`
--
ALTER TABLE `tabel_kategori`
  ADD PRIMARY KEY (`idKategori`);

--
-- Indexes for table `tabel_keranjang`
--
ALTER TABLE `tabel_keranjang`
  ADD PRIMARY KEY (`idKeranjang`);

--
-- Indexes for table `tabel_komentar`
--
ALTER TABLE `tabel_komentar`
  ADD PRIMARY KEY (`idKomen`);

--
-- Indexes for table `tabel_produk`
--
ALTER TABLE `tabel_produk`
  ADD PRIMARY KEY (`idProduk`);

--
-- Indexes for table `tabel_transaksi`
--
ALTER TABLE `tabel_transaksi`
  ADD PRIMARY KEY (`idTransaksi`);

--
-- Indexes for table `tabel_trolly`
--
ALTER TABLE `tabel_trolly`
  ADD PRIMARY KEY (`idTrolly`);

--
-- Indexes for table `tabel_user`
--
ALTER TABLE `tabel_user`
  ADD PRIMARY KEY (`idUser`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tabel_komentar`
--
ALTER TABLE `tabel_komentar`
  MODIFY `idKomen` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tabel_produk`
--
ALTER TABLE `tabel_produk`
  MODIFY `idProduk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `tabel_transaksi`
--
ALTER TABLE `tabel_transaksi`
  MODIFY `idTransaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tabel_trolly`
--
ALTER TABLE `tabel_trolly`
  MODIFY `idTrolly` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `tabel_user`
--
ALTER TABLE `tabel_user`
  MODIFY `idUser` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
